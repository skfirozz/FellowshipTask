package com.ms.API;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;


@RestController
@RequestMapping("/myController")
public class MyController {
    
    @GetMapping("/get")
    public ResponseEntity<Map<String, Object>> getMethodName() {
        
        Map<String, Object> map = new HashMap<>();
        map.put("data", "This is the body of the response");
        map.put("status", "success");
        return ResponseEntity.ok(map);

    }
    
}
